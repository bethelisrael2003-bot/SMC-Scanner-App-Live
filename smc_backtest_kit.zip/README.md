# Quantitative Backtest Kit & Candle Dataset (92 Days, 11 Pairs)

This package contains tick-accurate historical broker data (Capital.com demo feed) from **June 16, 2026 to September 16, 2026** across 11 Forex & Metals pairs.

## Files Included:
- `backtest_runner.py`: A self-contained, zero-dependency Python simulation engine with realistic spread-aware execution, position limits, session hours, and R-multiple tracking.
- `data/*.json`: Clean OHLC candles for all 11 pairs across M15, H1, H4, and D1 timeframes.

## Quick Start:
Run the simulation in Python:
```bash
python3 backtest_runner.py
```

## How to Test a New Strategy:
Open `backtest_runner.py`, implement your strategy logic inside the `my_custom_strategy(pair_data)` function, and run it. The runner will automatically evaluate your signals across all 11 pairs and print the complete performance breakdown (Trades, Win Rate, Total R, Profit Factor, Drawdown).
